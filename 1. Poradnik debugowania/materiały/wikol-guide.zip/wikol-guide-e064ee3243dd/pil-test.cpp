#include <cstdio>
#include <cstdlib>

int main() {
  while (true) {
    system("./pil-gen > pil.in");
    system("./pil < pil.in > pil.out");
    system("./pil-brut < pil.in > pil-brut.out");
    if (system("diff pil.out pil-brut.out")) {
      printf("ANS\n");
      break;
    } else {
      printf("OK\n");
    }
  }
}
