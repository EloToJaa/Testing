from random import randint

min_t = 2 * 1000 * 1000 * 1000
max_t = 2 * 1000 * 1000 * 1000
min_n = 3 * 1000 * 1000
max_n = 3 * 1000 * 1000
min_value = 2 * 1000 * 1000 * 1000
max_value = 2 * 1000 * 1000 * 1000

t = randint(min_t, max_t)
n = randint(min_n, max_n)

print t,n
for i in range(n):
    print randint(min_value, max_value),
