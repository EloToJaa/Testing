from os import system

while 1:
    system("python pil-gen.py > pil.in")
    system("./pil < pil.in > pil.out")
    system("./pil-brut < pil.in > pil-brut.out")
    if system("diff pil.out pil-brut.out"):
        print "ANS"
        break
    else:
        print "OK"
