#include <cstdio>
#include <algorithm>

using namespace std;

const int MAXN = 3 * 1000 * 1000;
const int INF = 2 * 1000 * 1000 + 1;
int input[MAXN];
int n,t;

inline int dist(int a, int b) {
  return max(a,b) - min(a,b);
}

void read() {
  scanf("%d%d", &t, &n);
  for (int i = 0;i < n;i++) {
    scanf("%d", &input[i]);
  }
}

int checkBegin(int begin) {
  int best = 0;
  int currentMin = INF, currentMax = 0;
  for (int end = begin;end < n;end++) {
    currentMin = min(currentMin, input[end]);
    currentMax = max(currentMax, input[end]);
    if (currentMax - currentMin > t) {
      break;
    } else {
      best = end - begin + 1;
    }
  }
  return best;
}

void solve() {
  int best = 0;
  for (int begin = 0;begin < n;begin++) {
    best = max(best, checkBegin(begin));
  }
  printf("%d\n", best);
}

int main() {
  read();
  solve();
  return 0;
}
