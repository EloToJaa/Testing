#include <cstdio>
#include <algorithm>

using namespace std;

const int INF = 2 * 1000 * 1000 + 1;
const int MAXN = 3 * 1000 * 1000;

struct Queue {
  int data[MAXN];
  int begin, end;
  Queue() : begin(0), end(0) {}

  void push_back(int value) {
    data[end] = value;
    end++;
  }

  int front() {
    return data[begin];
  }

  int back() {
    return data[end-1];
  }

  void pop_front() {
    begin++;
  }

  void pop_back() {
    end--;
  }

  int size() {
    return end - begin;
  }

  bool empty() {
    return begin == end;
  }
};

struct QueueWithMinMax {
  Queue all;
  Queue forMin;
  Queue forMax;

  void push(int value) {
    all.push_back(value);
    while (!forMin.empty() && forMin.back() > value) {
      forMin.pop_back();
    }
    forMin.push_back(value);
    while (!forMax.empty() && forMax.back() < value) {
      forMax.pop_back();
    }
    forMax.push_back(value);
  }

  void pop() {
    if (forMin.front() == all.front()) {
      forMin.pop_front();
    }
    if (forMax.front() == all.front()) {
      forMax.pop_front();
    }
    all.pop_front();
  }

  int getMin() {
    if (forMin.empty()) {
      return INF;
    } else {
      return forMin.front();
    }
  }

  int getMax() {
    if (forMax.empty()) {
      return 0;
    } else {
      return forMax.front();
    }
  }

  int size() {
    return all.size();
  }

};

QueueWithMinMax queue;
int t,n;
int input[MAXN];

void read() {
  scanf("%d%d", &t, &n);
  for (int i = 0;i < n;i++) {
    scanf("%d", &input[i]);
  }
}

void solve() {
  int best = 0;
  for (int i = 0;i < n;i++) {
    queue.push(input[i]);
    while (queue.getMax() - queue.getMin() > t) {
      queue.pop();
    }
    best = max(best, queue.size());
  }
  printf("%d\n", best);
}

int main() {
  read();
  solve();
  return 0;
}
