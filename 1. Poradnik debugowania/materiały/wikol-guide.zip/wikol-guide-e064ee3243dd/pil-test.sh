while true; do
  ./pil-gen > pil.in
  ./pil < pil.in > pil.out
  ./pil-brut < pil.in > pil-brut.out
  diff pil.out pil-brut.out
  if [ $? -ne 0 ]; then
    echo "ANS"
    break
  else
    echo "OK"
  fi
done
