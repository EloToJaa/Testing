#include <cstdio>
#include <cstdlib>
#include <ctime>

const int min_t = 1, max_t = 100;
const int min_n = 1, max_n = 100;
const int min_value = 1, max_value = 100;

int randint(int minv, int maxv) {
  return rand() % (maxv - minv + 1) + minv;
}

int main() {
  srand(time(0));
  int t = randint(min_t, max_t);
  int n = randint(min_n, max_n);
  printf("%d %d\n", t, n);
  for (int i = 0; i<n ;i++) {
    printf("%d ", randint(min_value, max_value));
  }
  printf("\n");
}
